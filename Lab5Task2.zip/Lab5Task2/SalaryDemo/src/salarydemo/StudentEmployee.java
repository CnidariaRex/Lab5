package salarydemo;

public class StudentEmployee extends HourlyEmployee {

	private String department;
	private String supervisingProfessor;

	/**
	 * 
	 * @param name
	 * @param department
	 * @param professor
	 * @param wage
	 */
	public StudentEmployee(String name, String area, String teacher, double wage) {
		// TODO - implement StudentEmployee.StudentEmployee
                super(name, wage);
		department = area;
                supervisingProfessor = teacher;
                
                
	}

	/**
	 * 
	 * @param hoursWork
	 */
	public double weeklyPay(int hoursWorked)
        {            
            return super.weeklyPay(hoursWorked);
	}
        
        public void printStudent(int hoursWorked)
        {
            System.out.println("The student is: " + super.getName() + " with hours worked: " + hoursWorked + " at wage " + super.getWage() + " in department " + department + " under professor " + supervisingProfessor + "for pay of " + weeklyPay(hoursWorked));
        }

}