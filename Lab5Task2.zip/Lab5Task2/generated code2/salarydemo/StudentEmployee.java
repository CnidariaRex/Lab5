package salarydemo;

public class StudentEmployee extends HourlyEmployee {
	private String _department;
	private String _supervisingProfessor;

	public StudentEmployee(String aName, String aDepartment, String aProfessor, double aWage) {
		throw new UnsupportedOperationException();
	}

	public double weeklyPay(int aHoursWork) {
		throw new UnsupportedOperationException();
	}
}