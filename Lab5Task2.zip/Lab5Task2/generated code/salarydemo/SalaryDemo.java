package salarydemo;

/**
 * This program demonstrates polymorphism by applying a method
 *    to objects of different classes.
 */
public class SalaryDemo {

	public static void main(String[] aArgs) {
		throw new UnsupportedOperationException();
	}
}