package elevatorcontroller;

/**
 * @author Rex
 */
public class ElevatorView {

	ElevatorView() {
		throw new UnsupportedOperationException();
	}

	public void ElevatorPrint(String aString1) {
		throw new UnsupportedOperationException();
	}
}