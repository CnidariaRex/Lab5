package elevatorcontroller;

/**
 * @author Rex
 */
public class ElevatorController {
	/**
	 * @param args the command line arguments
	 */
	private static ElevatorView _view;
	private static ElevatorModel _model;

	public static void main(String[] aArgs) {
		throw new UnsupportedOperationException();
	}
}