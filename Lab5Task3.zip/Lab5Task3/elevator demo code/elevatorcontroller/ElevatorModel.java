package elevatorcontroller;

/**
 * @author Rex
 */
public class ElevatorModel {
	private int _mAX_CAPACITY;
	private int _nUM_FLOORS;
	private int _current_floor;
	private boolean _moving_up;
	private int[] _passenger_targets;

	/**
	 * Floor floors[];
	 */
	ElevatorModel(int aMAX_CAPACITY, int aNUM_FLOORS, int aCurrent_floor, boolean aMoving_up) {
		throw new UnsupportedOperationException();
	}

	public String toString() {
		throw new UnsupportedOperationException();
	}

	public void move() {
		throw new UnsupportedOperationException();
	}

	public void boardPassenger(int aFloor) {
		throw new UnsupportedOperationException();
	}
}